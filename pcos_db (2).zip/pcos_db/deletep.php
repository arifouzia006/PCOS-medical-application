<?php
// Include the database configuration
include 'config.php'; // Adjust the path if necessary

header('Content-Type: application/json');

// Check if the name is provided via POST
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['name'])) {
    $name = trim($_POST['name']);

    // Prepare DELETE queries for each table
    $queries = [
        'personaldetails' => 'DELETE FROM personal_details WHERE name = ?',
        'users' => 'DELETE FROM users WHERE username = ?',
        'signup' => 'DELETE FROM signup WHERE username = ?',
        'leaderboard' => 'DELETE FROM leaderboard WHERE Name = ?',
    ];

    $response = [];

    // Execute each DELETE query
    foreach ($queries as $table => $query) {
        $stmt = $conn->prepare($query);
        if ($stmt === false) {
            $response[$table] = "Error preparing statement for $table: " . $conn->error;
            continue;
        }

        $stmt->bind_param('s', $name);

        try {
            $stmt->execute();
            $response[$table] = "Records deleted successfully from the $table table.";
        } catch (Exception $e) {
            $response[$table] = "Error deleting record in $table: " . $e->getMessage();
        }

        $stmt->close();
    }

    // Send JSON response
    echo json_encode($response);
} else {
    $response = ["error" => "Name not provided or incorrect request method."];
    echo json_encode($response);
}

// Close the database connection
$conn->close();
?>
