<?php
// Include the database configuration file
include 'config.php';

// Set content-type to JSON
header('Content-Type: application/json');

// Get JSON POST body and convert it to PHP array
$data = json_decode(file_get_contents("php://input"), true);

$name = isset($data['name']) ? $data['name'] : '';
$mild = isset($data['mild']) ? (float)$data['mild'] : 0.0;
$moderate = isset($data['moderate']) ? (float)$data['moderate'] : 0.0;
$severe = isset($data['severe']) ? (float)$data['severe'] : 0.0;

// Calculate the next assessment date, which is 14 days from today
$nextAssessmentDate = (new DateTime())->add(new DateInterval('P14D'))->format('Y-m-d');

// Prepare SQL statement to check if the name already exists
if ($checkStmt = $conn->prepare("SELECT * FROM score WHERE name = ?")) {
    $checkStmt->bind_param("s", $name);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Name exists, update the record
        $updateSql = "UPDATE score SET mild = ?, moderate = ?, severe = ?, next_assessment_date = ? WHERE name = ?";
        if ($updateStmt = $conn->prepare($updateSql)) {
            $updateStmt->bind_param("dddss", $mild, $moderate, $severe, $nextAssessmentDate, $name);
            if ($updateStmt->execute()) {
                echo json_encode(['success' => 'Record updated successfully']);
            } else {
                echo json_encode(['error' => 'Error updating record: ' . $updateStmt->error]);
            }
            $updateStmt->close();
        }
    } else {
        // Name does not exist, insert a new record
        $insertSql = "INSERT INTO score (name, mild, moderate, severe, next_assessment_date) VALUES (?, ?, ?, ?, ?)";
        if ($insertStmt = $conn->prepare($insertSql)) {
            $insertStmt->bind_param("sddds", $name, $mild, $moderate, $severe, $nextAssessmentDate);
            if ($insertStmt->execute()) {
                echo json_encode(['success' => 'New record created successfully']);
            } else {
                echo json_encode(['error' => 'Error: ' . $insertStmt->error]);
            }
            $insertStmt->close();
        }
    }
    $checkStmt->close();
} else {
    echo json_encode(['error' => 'Failed to prepare statement: ' . $conn->error]);
}

$conn->close();
?>
