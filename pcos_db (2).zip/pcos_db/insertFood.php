<?php
// Include config.php for database connection
include 'config.php';

header('Content-Type: application/json');

$response = array();

try {
    // Check if data is valid
    if (isset($_POST['name']) && isset($_POST['type']) && isset($_POST['calorie'])) {
        $name = $_POST['name'];
        $type = $_POST['type']; // This should be 'breakfast', 'lunch', or 'dinner'
        $calorie = $_POST['calorie'];

        // Determine the column name based on the type
        $columnName = '';
        switch ($type) {
            case 'breakfast':
                $columnName = 'breakfast';
                break;
            case 'lunch':
                $columnName = 'lunch';
                break;
            case 'dinner':
                $columnName = 'dinner';
                break;
            default:
                $response = ['error' => true, 'message' => 'Invalid type'];
                echo json_encode($response);
                exit;
        }

        // Make sure the column name is valid
        $allowedColumns = ['breakfast', 'lunch', 'dinner'];
        if (!in_array($columnName, $allowedColumns)) {
            $response = ['error' => true, 'message' => 'Invalid column name'];
            echo json_encode($response);
            exit;
        }

        // First, check if the name already exists
        $checkStmt = $conn->prepare("SELECT COUNT(*) FROM food_calorie WHERE name = ?");
        if (!$checkStmt) {
            throw new Exception("Error preparing select query: " . $conn->error);
        }
        $checkStmt->bind_param("s", $name);
        $checkStmt->execute();
        $checkStmt->store_result(); // Store the result
        $checkStmt->bind_result($rowCount);
        $checkStmt->fetch();
        $checkStmt->free_result(); // Free the result set

        // If the name exists, update the existing data, else insert a new row
        if ($rowCount > 0) {
            $updateStmt = $conn->prepare("UPDATE food_calorie SET $columnName = ? WHERE name = ?");
            if (!$updateStmt) {
                throw new Exception("Error preparing update query: " . $conn->error);
            }
            $updateStmt->bind_param("is", $calorie, $name);
            $updateStmt->execute();
            $updateStmt->free_result(); // Free the result set
        } else {
            $insertStmt = $conn->prepare("INSERT INTO food_calorie (name, $columnName) VALUES (?, ?)");
            if (!$insertStmt) {
                throw new Exception("Error preparing insert query: " . $conn->error);
            }
            $insertStmt->bind_param("si", $name, $calorie);
            $insertStmt->execute();
            $insertStmt->free_result(); // Free the result set
        }

        // After inserting or updating, calculate the total calorie
        $totalCalStmt = $conn->prepare("UPDATE food_calorie SET total_calorie = (IFNULL(breakfast, 0) + IFNULL(lunch, 0) + IFNULL(dinner, 0)) WHERE name = ?");
        if (!$totalCalStmt) {
            throw new Exception("Error preparing total calorie query: " . $conn->error);
        }
        $totalCalStmt->bind_param("s", $name);
        $totalCalStmt->execute();
        $totalCalStmt->free_result(); // Free the result set

        $response = ['error' => true, 'message' => 'Operation completed successfully'];
    } else {
        $response = ['error' => true, 'message' => 'Invalid data'];
    }

} catch (Exception $e) {
    $response = ['error' => true, 'message' => 'Operation failed: ' . $e->getMessage()];
}

// Output the JSON response
echo json_encode($response);
?>
