<?php
// Include the config.php file for the database connection
include 'config.php';

// Check if name is provided using $_POST
if (isset($_POST['name'])) {
    $name = $_POST['name'];

    // Prepare the select statement
    $selectStmt = $conn->prepare("SELECT fat, pro, carb FROM food WHERE name = ?");
    $selectStmt->bind_param('s', $name);
    $selectStmt->execute();
    $result = $selectStmt->get_result();

    // Initialize arrays to hold the data
    $fats = [];
    $proteins = [];
    $carbs = [];

    // Check if any record exists
    if ($result->num_rows > 0) {
        // Fetch the data
        while ($row = $result->fetch_assoc()) {
            $fats[] = $row['fat'];
            $proteins[] = $row['pro'];
            $carbs[] = $row['carb'];
        }
        // Package and return the data
        echo json_encode(['fats' => $fats, 'proteins' => $proteins, 'carbs' => $carbs]);
    } else {
        echo json_encode(["error" => "No data found for the provided name."]);
    }

    // Close the statement
    $selectStmt->close();
} else {
    echo json_encode(["error" => "Name not provided."]);
}

// Close the database connection
$conn->close();
?>
