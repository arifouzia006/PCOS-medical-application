<?php
// Include config.php for database connection
include 'config.php';

$response = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];

    // Validate data
    if (empty($name)) {
        $response = ["status" => "error", "message" => "Name is required."];
    } else {
        try {
            // Fetch data from the database for entries created in the last month
            $sql = "SELECT name, meal_plan, meal_percentage, exercise_plan, exercise_percentage, meditation_routine, meditation_percentage, no_meal, no_meditation, no_exercise, DATE_FORMAT(created_at, '%Y-%m-%d') as created_at 
                    FROM health_plan 
                    WHERE name = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MONTH)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            $data = $result->fetch_all(MYSQLI_ASSOC);

            // Replace null values with empty strings
            $data = array_map(function($row) {
                return array_map(function($value) {
                    return is_null($value) ? '' : $value;
                }, $row);
            }, $data);

            if ($data) {
                $response = ["status" => "success", "data" => $data];
            } else {
                $response = ["status" => "failure", "data" => []]; // Ensuring data is always an array
            }
        } catch (\Exception $e) {
            $response = ["status" => "error", "message" => $e->getMessage()];
        }
    }
} else {
    $response = ["status" => "error", "message" => "Invalid request method."];
}

// Set the Content-Type to application/json
header('Content-Type: application/json');
echo json_encode($response);
?>
