<?php
header('Content-Type: application/json');
include("config.php");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$uploadDir = "uploads/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['image']) && isset($_POST['name'])) {
    $name = $_POST['name'];
    $imageData = $_POST['image'];  // Base64 encoded image string

    // Decode the base64 image
    $decodedImage = base64_decode($imageData);

    // Generate a unique filename for the image
    $imageName = uniqid() . '.jpg';
    $targetFile = $uploadDir . $imageName;

    // Save the decoded image to the target directory
    if (file_put_contents($targetFile, $decodedImage)) {
        // Update the database with the image path
        $sql = "UPDATE personal_details SET profile_image = ? WHERE name = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param('ss', $imageName, $name);

            if ($stmt->execute()) {
                echo json_encode([
                    "success" => true,
                    "message" => "Profile image updated successfully.",
                    "image_url" => $targetFile
                ]);
            } else {
                echo json_encode(["success" => false, "error" => "Error updating profile image in the database: " . $stmt->error]);
            }
            $stmt->close();
        } else {
            echo json_encode(["success" => false, "error" => "Error preparing the SQL statement: " . $conn->error]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "Error saving the image file."]);
    }
} else {
    echo json_encode(["success" => false, "error" => "Invalid request. Make sure all fields are included."]);
}

$conn->close();
?>
