<?php
// Include config.php for database connection
include 'config.php';

header('Content-Type: application/json');

$response = array();

try {
    // Check if the 'name' parameter is provided
    if (isset($_GET['name'])) {
        $name = $_GET['name'];

        // Prepare a select statement
        $stmt = $conn->prepare("SELECT total_calorie FROM food_calorie WHERE name = ?");
        $stmt->bind_param("s", $name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $totalCalorie = (int) $row['total_calorie'];
            $response = ['success' => true, 'total_calorie' => $totalCalorie];
        } else {
            // Name not found in the database
            $response = ['success' => false, 'message' => "No calorie data found for the specified name."];
        }

        $stmt->close();
    } else {
        // Name parameter not provided
        $response = ['success' => false, 'message' => "Name parameter is required."];
    }
} catch (Exception $e) {
    $response = ['success' => false, 'message' => $e->getMessage()];
}

// Output the JSON response
echo json_encode($response);

// Close the database connection
$conn->close();
?>
