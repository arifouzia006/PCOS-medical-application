<?php
header('Content-Type: application/json'); // Set the response content type to JSON

// Include the database connection configuration
include("config.php");

$response = array(); // Create an associative array for the response

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $doctor_id = $_POST['doctor_id'];
    $password = $_POST['password'];

    // Validate and sanitize user input as needed
    // Sanitization example for basic security (additional security measures like prepared statements are used below)
    $doctor_id = filter_var($doctor_id, FILTER_SANITIZE_STRING);
    $password = filter_var($password, FILTER_SANITIZE_STRING);

    // Check the database for user credentials and role
    $sql = "SELECT * FROM users WHERE username = ? AND password = ? AND role = 'doctor'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $doctor_id, $password);
    $stmt->execute();
    
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if ($user) {
        $response['success'] = true;
        $response['message'] = "Login Successful";
        // Removed the section that adds user information to the response
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid username or password, or not a doctor";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method";
}

echo json_encode($response); // Encode the response as JSON and echo it

// Close the database connection
$conn->close();
?>
