<?php
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $Mobile_No = $_POST['Mobile_No'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $bmi = $_POST['bmi'];
    $otherdisease = $_POST['otherdisease'];
    $obstetricscore = $_POST['obstetricscore'];
    $hip = $_POST['hip'];
    $waist = $_POST['waist'];
    $hipwaist = $_POST['hipwaist'];
    $centralobesity = $_POST['centralobesity'];

    if (empty($name) || empty($age) || empty($Mobile_No) || empty($height) || empty($weight)) {
        $response['success'] = false;
        $response['message'] = "Error: Please fill in all fields.";
    } else {
        $insertSql = "INSERT INTO personal_details (name, age, Mobile_No, height, weight, bmi, otherdisease, obstetricscore, hip, waist, hipwaist, centralobesity) 
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $insertStmt = $conn->prepare($insertSql);

        if ($insertStmt === false) {
            $response['success'] = false;
            $response['message'] = "Failed to prepare statement for personal_details. Error: " . $conn->error;
        } else {
            $insertStmt->bind_param("sisddsssddds", 
                                    $name, 
                                    $age, 
                                    $Mobile_No, 
                                    $height, 
                                    $weight, 
                                    $bmi, 
                                    $otherdisease, 
                                    $obstetricscore, 
                                    $hip, 
                                    $waist, 
                                    $hipwaist, 
                                    $centralobesity);

            if ($insertStmt->execute()) {
                $response['success'] = true;
                $response['message'] = "Personal details inserted successfully.";

                // Retrieve the latest month value for this name
                $selectMonthSql = "SELECT months FROM weight_graph WHERE name = ? ORDER BY months DESC LIMIT 1";
                $selectMonthStmt = $conn->prepare($selectMonthSql);

                if ($selectMonthStmt === false) {
                    $response['success'] = false;
                    $response['message'] = "Failed to prepare statement for weight_graph. Error: " . $conn->error;
                } else {
                    $selectMonthStmt->bind_param("s", $name);
                    $selectMonthStmt->execute();
                    $result = $selectMonthStmt->get_result();
                    $currentMonth = $result->fetch_assoc() ? $result->fetch_assoc()['months'] + 1 : 1;

                    // Insert name, weight, and month into the weight_graph table
                    $insertGraphSql = "INSERT INTO weight_graph (name, weight_value, months) VALUES (?, ?, ?)";
                    $insertGraphStmt = $conn->prepare($insertGraphSql);

                    if ($insertGraphStmt === false) {
                        $response['success'] = false;
                        $response['message'] = "Failed to prepare statement for inserting into weight_graph. Error: " . $conn->error;
                    } else {
                        $insertGraphStmt->bind_param("sid", $name, $weight, $currentMonth);

                        if ($insertGraphStmt->execute()) {
                            $response['message'] .= " Weight graph updated successfully with month increment.";
                        } else {
                            $errorInfo = $insertGraphStmt->error;
                            $response['success'] = false;
                            $response['message'] .= " Failed to insert into weight_graph. Error: " . $errorInfo;
                        }
                    }
                }
            } else {
                $response['success'] = false;
                $errorInfo = $insertStmt->error;
                $response['message'] = "Unable to insert data into the 'personal_details' table. Error: " . $errorInfo;
            }
        }
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

$conn->close(); // Close the database connection

header('Content-Type: application/json');
echo json_encode($response);
?>
