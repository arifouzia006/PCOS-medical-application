<?php
header('Content-Type: application/json');
require_once 'config.php'; 

$response = []; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['category'])) {
    $userCategory = $_POST['category'];

    $sql = "SELECT audio_name, audio_path, audio_description, duration FROM meditation WHERE category = ?";
    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $userCategory);

    try {
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc(); 
            
            $response = [
                "audio_name" => $row['audio_name'],
                "audio_description" => $row['audio_description'],
                "audio_path" => $baseURL . $row['audio_path'], 
                "duration" => $row['duration']
            ];
        } else {
            $response["error"] = "Audio not found.";
        }
    } catch (Exception $e) {
        $response["error"] = "Error in executing SQL query: " . $e->getMessage();
    }
} else {
    $response["error"] = "Invalid request. Please provide a valid 'category' parameter in a POST request.";
}

echo json_encode($response);
?>