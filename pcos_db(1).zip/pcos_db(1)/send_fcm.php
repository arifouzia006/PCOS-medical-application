<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $fcmToken = $data['fcm_token'] ?? '';

    // Store the FCM token in your database
    $conn = new mysqli('localhost', 'username', 'password', 'database');
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("INSERT INTO fcm_tokens (token) VALUES (?)");
    $stmt->bind_param("s", $fcmToken);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    echo json_encode(['message' => 'FCM token stored successfully.']);
} else {
    echo json_encode(['message' => 'Invalid request method.']);
}
?>
