<?php
header('Content-Type: application/json');

include("config.php");
error_reporting(E_ALL);
ini_set('display_errors', 1);

$uploadDir = "uploads/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name']) && isset($_FILES['image'])) {
    $name = $_POST['name'];
    $imageFile = $_FILES['image'];

    // Check if the image file is valid
    if ($imageFile['error'] == 0 && $imageFile['size'] > 0) {
        $imageName = time() . '.jpg'; // Generate a unique filename
        $targetFile = $uploadDir . $imageName;

        // Move the uploaded file to the target directory
        if (move_uploaded_file($imageFile['tmp_name'], $targetFile)) {
            // Updating the personaldetails table where the name matches
            $sql = "UPDATE personal_details SET profile_image = ? WHERE name = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $imageName, $name);

            if ($stmt->execute()) {
                echo json_encode(["message" => "Profile image updated successfully.", "image_url" => $targetFile]);
            } else {
                echo json_encode(["error" => "Error updating profile image in the database: " . $conn->error]);
            }
        } else {
            echo json_encode(["error" => "Error uploading image file."]);
        }
    } else {
        echo json_encode(["error" => "Invalid image file."]);
    }
} else {
    echo json_encode(["error" => "Invalid request. Please make sure you are sending a POST request with all required fields and including an 'image' file."]);
}
?>