<?php
// Include the database connection configuration
include("config.php");

$response = array();

try {
    // SQL query to get the top 10 high scores from the leaderboard table, including profile images from personal_details table
    $sql = "SELECT lb.Name, lb.Totalscore, pd.profile_image
            FROM leaderboard lb
            LEFT JOIN personal_details pd ON lb.Name = pd.Name
            ORDER BY lb.Totalscore DESC
            LIMIT 10";

    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch the results
    $results = $stmt->get_result();

    // Output the results in array format
    $topScoresArray = array();
    while ($row = $results->fetch_assoc()) {
        // Append the base URL to the profile image path if profile_image is not null or empty
        $profileImagePath = !empty($row['profile_image']) ? $baseURL . "uploads/" . $row['profile_image'] : null;
        
        $topScoresArray[] = array(
            'Name' => $row['Name'],
            'Totalscore' => (int) $row['Totalscore'], // Cast Totalscore to integer
            'ProfileImage' => $profileImagePath
        );
    }

    $response['success'] = true;
    $response['message'] = "Top 10 high scores with profile images.";
    $response['top_scores'] = $topScoresArray;
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = "Error: " . $e->getMessage();
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>