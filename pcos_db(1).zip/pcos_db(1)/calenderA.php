<?php
include 'config.php'; // Assuming this file contains the MySQLi connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!empty($_POST['name']) && !empty($_POST['dates'])) {
        $name = $_POST['name'];
        $dates = $_POST['dates']; // This is expected to be an array

        try {
            $conn->begin_transaction();

            $stmt = $conn->prepare("INSERT INTO calender (name, calendar_date) VALUES (?, ?)");

            foreach ($dates as $date) {
                $stmt->bind_param("ss", $name, $date);
                $stmt->execute();
            }

            $conn->commit();
            echo json_encode(['success' => true, 'message' => 'Dates inserted successfully']);
        } catch (Exception $e) {
            $conn->rollback();
            echo json_encode(['error' => 'Failed to insert dates: ' . $e->getMessage()]);
        }

        $stmt->close();
    } else {
        echo json_encode(['error' => 'Name or dates not provided']);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method. Only POST is allowed']);
}

$conn->close();
?>
