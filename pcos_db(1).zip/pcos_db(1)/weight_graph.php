<?php
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['name'])) {
        $name = $_POST['name'];

        $sql = "SELECT months, weight_value FROM weight_graph WHERE name = ? ORDER BY months ASC";
        $stmt = mysqli_prepare($conn, $sql);
        
        // Bind parameters
        mysqli_stmt_bind_param($stmt, 's', $name);
        
        // Execute the query
        if(mysqli_stmt_execute($stmt)) {
            $result = mysqli_stmt_get_result($stmt);
            if(mysqli_num_rows($result) > 0) {
                $chartData = [];
                while ($row = mysqli_fetch_assoc($result)) {
                    $chartData[] = [
                        'x' => (float)$row['months'],
                        'y' => (float)$row['weight_value'] 
                    ];
                }

                $response['success'] = true;
                $response['message'] = "Data fetched successfully.";
                $response['data'] = $chartData;
            } else {
                $response['success'] = false;
                $response['message'] = "No data found for the provided name.";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Failed to execute query.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Name is required.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method. Please use POST.";
}

mysqli_close($conn);

header('Content-Type: application/json');
echo json_encode($response);
?>