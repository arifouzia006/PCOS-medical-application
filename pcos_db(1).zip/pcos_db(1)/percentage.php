<?php
// Include database configuration file
include("config.php");

// Define maximum values for calculations
define("MAX_CALORIES", 1500); // Example maximum calories
define("MAX_STEPS", 15000);    // Example maximum steps
define("MAX_FEEDBACK", 10);    // Example maximum feedback score

$response = array();

try {
    // Collect the 'name' from POST request
    $name = isset($_POST['name']) ? $_POST['name'] : null;
    
    // Check if name is provided
    if (empty($name)) {
        throw new Exception("Name is required.");
    }
    
    // Prepare SQL query to fetch the most recent record for the given name
    $sql = "SELECT calories_taken, no_of_steps, todays_feedback, date 
            FROM today_progress 
            WHERE name = ? 
            ORDER BY date DESC 
            LIMIT 1";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();

    $result = $stmt->get_result();

    // Check if any record exists
    if ($result->num_rows > 0) {
        // Fetch the data
        $data = $result->fetch_assoc();
        
        // Calculate and round percentages
        $calories_percentage = round(($data['calories_taken'] / MAX_CALORIES) * 100);
        $steps_percentage = round(($data['no_of_steps'] / MAX_STEPS) * 100);
        $feedback_percentage = round(($data['todays_feedback'] / MAX_FEEDBACK) * 100);
        
        // Set success response with rounded percentages
        $response['success'] = true;
        $response['message'] = "Data retrieved successfully.";
        $response['percentages'] = array(
            'calories_percentage' => $calories_percentage,
            'steps_percentage' => $steps_percentage,
            'feedback_percentage' => $feedback_percentage
        );
    } else {
        throw new Exception("No data found for the provided name.");
    }
} catch (Exception $e) {
    // Catch any exception and set the error message in response
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

// Close connection
$conn->close();

// Set header to return JSON content
header('Content-Type: application/json');
// Return response in JSON format
echo json_encode($response);
?>