<?php
// Include the config.php file for database connection
include 'config.php';

// Initialize the response array
$response = array();

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the raw POST data and decode the JSON
    $postData = file_get_contents("php://input");
    $data = json_decode($postData, true);

    // Extract the required fields from the JSON
    $name = $data['username'] ?? null;
    $meal_plan = $data['meal_plan'] ?? null;
    $meal_percentage = $data['meal_percentage'] ?? null;
    $exercise_plan = $data['exercise_plan'] ?? null;
    $exercise_percentage = $data['exercise_percentage'] ?? null;
    $meditation_plan = $data['meditation_plan'] ?? null;
    $meditation_percentage = $data['meditation_percentage'] ?? null;

    // Validate the input data
    if (empty($name) || !is_numeric($meal_percentage) || !is_numeric($exercise_percentage) || !is_numeric($meditation_percentage)) {
        $response = ["status" => "error", "message" => "Invalid input. Make sure all fields are filled and percentages are numeric."];
    } else {
        // Attempt to insert data into the database
        try {
            // Prepare the SQL query
            $sql = "INSERT INTO health_plan (
                        name, meal_plan, meal_percentage, exercise_plan, exercise_percentage, 
                        meditation_routine, meditation_percentage
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    
            // Prepare the statement
            $stmt = $conn->prepare($sql);
            
            // Bind parameters to the statement
            $stmt->bind_param("sssssss", $name, $meal_plan, $meal_percentage, $exercise_plan, $exercise_percentage, $meditation_plan, $meditation_percentage);
            
            // Execute the statement
            $stmt->execute();

            // Respond with success if the query was successful
            $response = ["status" => "success", "message" => "Data successfully inserted!"];
        } catch (Exception $e) {
            // Handle any errors
            $response = ["status" => "error", "message" => $e->getMessage()];
        }
    }
} else {
    // Respond with an error if the request method is not POST
    $response = ["status" => "error", "message" => "Invalid request method."];
}

// Set the response content-type to JSON
header('Content-Type: application/json');

// Echo the response in JSON format
echo json_encode($response);
?>
