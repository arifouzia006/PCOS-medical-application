<?php
// Include the database connection configuration
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $age = $_POST['age'];
    $Mobile_No = $_POST['Mobile_No'];
    $height = $_POST['height'];
    $weight = $_POST['weight'];
    $bmi = $_POST['bmi'];
    $otherdisease = $_POST['otherdisease']; // Ensure the keys are case-sensitive and matched in both client and server code

    // Attempt to update the record
    $updateSql = "UPDATE personal_details SET age = ?, Mobile_No = ?, height = ?, weight = ?, bmi = ?, otherdisease = ? WHERE name = ?";
    $updateStmt = $conn->prepare($updateSql);

    // Bind parameters
    $updateStmt->bind_param('issssss', $age, $Mobile_No, $height, $weight, $bmi, $otherdisease, $name);

    if ($updateStmt->execute()) {
        // Check if any row was updated
        if ($updateStmt->affected_rows > 0) {
            $response['success'] = true;
            $response['message'] = "Personal details updated successfully.";

            // Retrieve the latest month value for this name
            $selectMonthSql = "SELECT months FROM weight_graph WHERE name = ? ORDER BY months DESC LIMIT 1";
            $selectMonthStmt = $conn->prepare($selectMonthSql);
            $selectMonthStmt->bind_param('s', $name);
            $selectMonthStmt->execute();
            $selectMonthStmt->bind_result($currentMonth);
            $selectMonthStmt->fetch();
            $currentMonth = $currentMonth ? $currentMonth + 1 : 1;
            $selectMonthStmt->close();

            // Insert name, weight, and month into the weight_graph table
            $insertGraphSql = "INSERT INTO weight_graph (name, weight_value, months) VALUES (?, ?, ?)";
            $insertGraphStmt = $conn->prepare($insertGraphSql);
            $insertGraphStmt->bind_param('ssi', $name, $weight, $currentMonth);

            if ($insertGraphStmt->execute()) {
                $response['message'] .= " Weight graph updated successfully with month increment.";
            } else {
                $response['success'] = false;
                $response['message'] .= " Failed to insert into weight_graph. Error: " . $insertGraphStmt->error;
            }
        } else {
            // No rows updated, likely because the name does not exist
            $response['success'] = false;
            $response['message'] = "No existing record found to update. No changes made.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Unable to update personal details.";
    }

    $updateStmt->close();
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>
