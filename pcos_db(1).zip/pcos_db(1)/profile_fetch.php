<?php

include 'config.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the name is provided
    if (isset($_POST['name']) && !empty($_POST['name'])) {
        // Prepare a statement to avoid SQL injection
        $stmt = $conn->prepare("SELECT profile_image FROM personal_details WHERE name = ?");
        $stmt->bind_param("s", $_POST['name']);
        
        // Execute the statement
        $stmt->execute();

        // Get the result
        $result = $stmt->get_result();

        // Check if there are any results
        if ($result->num_rows > 0) {
            // Fetch the data
            $row = $result->fetch_assoc();

            // Assuming your images are stored in an 'uploads' folder at the base URL
            $uploadsFolder = 'uploads/';

            // Construct the full image URL including the 'uploads' folder
            $imageUrl = $baseURL . $uploadsFolder . $row['profile_image'];

            // Return the image URL
            echo json_encode(array("success" => true, "image_url" => $imageUrl));
        } else {
            // No matching record found
            echo json_encode(array("success" => false, "message" => "No image found for the given name."));
        }
    } else {
        // Name not provided
        echo json_encode(array("success" => false, "message" => "Name is required."));
    }
} else {
    // Not a POST request
    echo json_encode(array("success" => false, "message" => "Invalid request method."));
}

// Close the connection
$conn->close();
?>