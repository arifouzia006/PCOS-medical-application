<?php

// Include config.php for database connection
include 'config.php';

// Fetch questions and options
$sql = "SELECT q.question_id, q.question, o.option_text
        FROM mcq_questions q
        JOIN mcq_questions_options o ON q.question_id = o.question_id
        ORDER BY q.question_id, o.option_text";

$stmt = $conn->prepare($sql);
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Fetch all results
$results = $result->fetch_all(MYSQLI_ASSOC);

// Check if there are results
if (count($results) > 0) {
    $questions = array();
    $currentQuestionId = null;
    $currentQuestion = null;

    // Process each row
    foreach ($results as $row) {
        $questionId = (int) $row['question_id'];  // Cast question_id to integer
        $questionText = $row['question'];
        $optionText = $row['option_text'];

        // If a new question is encountered, create a new question array
        if ($currentQuestionId !== $questionId) {
            // Add the previous question to the array if it exists
            if ($currentQuestion !== null) {
                $questions[] = $currentQuestion;
            }

            // Start a new question entry
            $currentQuestionId = $questionId;
            $currentQuestion = array(
                'question_id' => $questionId,  // Already cast to integer
                'question' => $questionText,
                'options' => array()
            );
        }

        // Add option to the current question if it is not a duplicate
        if (!in_array($optionText, array_column($currentQuestion['options'], 'option_text'))) {
            $currentQuestion['options'][] = array('option_text' => $optionText);
        }
    }

    // Add the last question to the array
    if ($currentQuestion !== null) {
        $questions[] = $currentQuestion;
    }

    // Create JSON response
    $response = array(
        'success' => true,
        'questions' => $questions
    );

    // Output JSON
    header('Content-Type: application/json');
    echo json_encode($response, JSON_PRETTY_PRINT);
} else {
    // No results found
    echo json_encode(array('success' => false, 'message' => 'No questions found.'));
}

?>
