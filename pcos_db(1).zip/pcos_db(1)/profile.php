<?php
// Include config.php for database connection and base URL
include 'config.php';

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect the patient name from the GET request
    $name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';

    // Prepare SQL query to select patient details including the profile image
    $sql = "SELECT name, age, Mobile_No, height, weight, bmi, otherdisease, obstetricscore, hip, waist, hipwaist, profile_image, centralobesity FROM personal_details WHERE name = ?";

    // Prepare the statement
    $stmt = $conn->prepare($sql);

    // Bind the 'name' parameter
    $stmt->bind_param("s", $name);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Fetch the patient details
    $patientDetails = $result->fetch_assoc();

    if ($patientDetails) {
        // Convert 'age' to an integer
        $patientDetails['age'] = (int)$patientDetails['age'];

        // Append the base URL to the profile image path if it exists
        if (!empty($patientDetails['profile_image'])) {
            $patientDetails['profile_image'] = $baseURL . "uploads/" . $patientDetails['profile_image'];
        }

        // Construct the response array
        $response['success'] = true;
        $response['message'] = "Patient details retrieved successfully.";
        $response['patient_details'] = $patientDetails;
    } else {
        $response['success'] = false;
        $response['message'] = "Patient not found.";
    }
} else {
    // Handle the case of an invalid request method
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

// Set the content type to JSON
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);
?>