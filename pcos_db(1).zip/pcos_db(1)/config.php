<?php
$host = 'localhost';
$database = 'pcos';
$username = 'root';
$password = '';
$baseURL = "http://14.139.187.229:8081/pcos_db/";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>