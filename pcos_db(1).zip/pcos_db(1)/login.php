<?php
header('Content-Type: application/json'); // Set the response content type to JSON

// Include the database connection configuration
include("config.php");

$response = array(); // Create an associative array for the response

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect query parameters
    $username = isset($_POST['username']) ? $_POST['username'] : null;
    $password = isset($_POST['password']) ? $_POST['password'] : null;

    // Validate and sanitize user input
    if (!empty($username)) {
        $username = filter_var($username, FILTER_SANITIZE_STRING);
    }
    if (!empty($password)) {
        $password = filter_var($password, FILTER_SANITIZE_STRING);
    }

    // Check if both username and password are provided
    if ($username !== null && $password !== null) {
        // Check the database for user credentials
        $sql = "SELECT COUNT(*) as count FROM users WHERE username = ? AND password = ? AND role = 'patient'";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $username, $password);
        $stmt->execute();
        
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row['count'] > 0) {
            // User credentials are correct, check if the user exists in personal_details
            $sqlDetails = "SELECT EXISTS(SELECT 1 FROM personal_details WHERE name = ?) AS userExists";
            $stmtDetails = $conn->prepare($sqlDetails);
            $stmtDetails->bind_param("s", $username);
            $stmtDetails->execute();
            $detailsResult = $stmtDetails->get_result();
            $detailsRow = $detailsResult->fetch_assoc();
            
            if ($detailsRow['userExists']) {
                $response['success'] = true;
                $response['message'] = "Login Successful, user details are complete.";
            } else {
                $response['success'] = true;
                $response['message'] = "Login Successful, please complete your personal details.";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Invalid username or password, or not a patient";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Username and password are required";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method";
}

echo json_encode($response); // Encode the response as JSON and echo it
?>