<?php
function sendPushNotification($fcmToken, $title, $body) {
    $url = "https://fcm.googleapis.com/fcm/send";
    $serverKey = 'AIzaSyBY443HNrozGQ0FsP1yGkLfuVNymGojLEg'; // Replace with your Firebase server key

    $notification = [
        'title' => $title,
        'body' => $body,
        'sound' => 'default'
    ];

    $data = [
        'to' => $fcmToken,
        'notification' => $notification,
        'priority' => 'high'
    ];

    $headers = [
        'Authorization: key=' . $serverKey,
        'Content-Type: application/json'
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

// Example usage:
$data = json_decode(file_get_contents('php://input'), true);
$fcmToken = $data['fcm_token'] ?? '';
$title = $data['title'] ?? 'Default Title';
$body = $data['body'] ?? 'Default Body';

$response = sendPushNotification($fcmToken, $title, $body);
echo $response;
?>
