<?php
// Include the database connection configuration
include("config.php");

$response = array();

// Assuming your users table has a column named 'username'
$selectUsernamesSql = "SELECT username FROM signup";
$selectUsernamesStmt = $conn->prepare($selectUsernamesSql);
$selectUsernamesStmt->execute();

$result = $selectUsernamesStmt->get_result();

if ($result->num_rows > 0) {
    // Fetch the usernames
    $usernames = array();
    while ($row = $result->fetch_assoc()) {
        $usernames[] = $row['username'];
    }

    $response['success'] = true;
    $response['usernames'] = $usernames;
} else {
    $response['success'] = false;
    $response['message'] = "No usernames found.";
}

// Close the database connection
$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>