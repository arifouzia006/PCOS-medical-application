<?php
header('Content-Type: application/json');
require 'config.php';

$response = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['name'])) {
    $name = $_POST['name'];
    $sql = "SELECT record_path FROM medical_record WHERE name = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 's', $name);

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_store_result($stmt);
            mysqli_stmt_bind_result($stmt, $record_path);

            $records = [];
            while (mysqli_stmt_fetch($stmt)) {
                if (!empty($record_path)) {
                    $fullPath = $baseURL . $record_path;
                    $records[] = ["record_path" => $fullPath];
                }
            }

            if (!empty($records)) {
                echo json_encode(["success" => true, "message" => "Record found", "records" => $records]);
            } else {
                echo json_encode(["success" => false, "message" => "No records found"]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Failed to execute query."]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Failed to prepare query."]);
    }
} else {
    echo json_encode(["success" => false, "message" => "Invalid request. Please use a POST request and provide a 'name' parameter."]);
}
?>