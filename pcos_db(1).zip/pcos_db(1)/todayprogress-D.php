<?php
// Include the database connection configuration
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Collect the name entered by the user from the URL parameter
    $name = isset($_GET['name']) ? htmlspecialchars($_GET['name']) : '';

    // Retrieve all details from the "today_progress" table for the specified name
    $sql = "SELECT Date, calories_taken, exercise_duration, todays_feedback, no_of_steps, name FROM today_progress WHERE name = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $name);
    $stmt->execute();
    $result = $stmt->get_result();
    $todayProgress = $result->fetch_assoc();

    if ($todayProgress) {
        // Cast numerical values to integer
        $todayProgress['calories_taken'] = (int) $todayProgress['calories_taken'];
        $todayProgress['exercise_duration'] = (int) $todayProgress['exercise_duration'];
        $todayProgress['no_of_steps'] = (int) $todayProgress['no_of_steps'];
        $todayProgress['todays_feedback'] = (int) $todayProgress['todays_feedback']; // Casting todays_feedback to integer

        $response['success'] = true;
        $response['message'] = "Today's progress details retrieved successfully.";
        $response['data'] = $todayProgress;
    } else {
        $response['success'] = false;
        $response['message'] = "Error: Today's progress for the provided name not found.";
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>