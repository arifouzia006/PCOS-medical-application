<?php
header('Content-Type: application/json');

require_once 'config.php';

$response = []; 

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['exercise_name'])) {
    $exercise_name = $_POST['exercise_name'];

    $sql = "SELECT exercise_name, video_description, video_url, duration, process FROM videos WHERE exercise_name = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $exercise_name);

    try {
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $response = [
                "exercise_name" => $row['exercise_name'],
                "video_description" => $row['video_description'],
                "video_url" => $baseURL . $row['video_url'], 
                "duration" => $row['duration'],
                "process" => $row['process']
            ];
        } else {
            $response["error"] = "Exercise not found.";
        }
    } catch (mysqli_sql_exception $e) {
        $response["error"] = "Error in executing SQL query: " . $e->getMessage();
    }
} else {
    $response["error"] = "Invalid request. Please provide a valid 'exercise_name' parameter in a POST request.";
}

echo json_encode($response);
?>