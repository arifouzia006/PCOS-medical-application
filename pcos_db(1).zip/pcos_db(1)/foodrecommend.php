<?php
include 'config.php'; // Include your config file

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Prepare an INSERT statement
        $sql = "INSERT INTO meal_plan (day, time, description) VALUES (:day, :time, :description)";

        $stmt = $conn->prepare($sql);

        // Insert each meal
        foreach (['6am', '8am', '11am', '2pm', '4pm', '8pm'] as $time) {
            $mealKey = "meal_" . $time;
            if (isset($_POST[$mealKey])) {
                $stmt->execute([
                    ':day' => 1, // Day number
                    ':time' => $time,
                    ':description' => $_POST[$mealKey]
                ]);
            }
        }

        echo "Meal plan submitted successfully.";
    }
} catch(PDOException $e) {
    die("ERROR: Could not connect. " . $e->getMessage());
}
?>
