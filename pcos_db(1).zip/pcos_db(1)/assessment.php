<?php
// Include the config.php file for database connection
include 'config.php';

// User's name, presumably obtained from user input or session
$username = isset($_GET['username']) ? $_GET['username'] : '';
// Make sure to sanitize and validate this value properly

// Prepare the statement to fetch the next assessment date for the user
$sql = "SELECT next_assessment_date FROM score WHERE name = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $username);
$stmt->execute();
$result = $stmt->get_result();
$userRow = $result->fetch_assoc();

if ($userRow) {
    $nextAssessmentDate = $userRow['next_assessment_date'];
    $currentDate = date('Y-m-d'); // Format the date according to your database's date format

    if ($currentDate == $nextAssessmentDate) {
        // Logic to proceed with the assessment
        $response = [
            'status' => 'success',
            'message' => 'Eligible to take assessment',
            'eligible' => true
        ];
    } else {
        // Inform the user about the next assessment date
        $response = [
            'status' => 'success',
            'message' => 'Your next assessment date is on ' . $nextAssessmentDate . '. You cannot take the assessment today.',
            'eligible' => false,
            'next_assessment_date' => $nextAssessmentDate
        ];
    }
} else {
    $response = [
        'status' => 'error',
        'message' => 'User not found or no assessment scheduled'
    ];
}

// Close statement and connection
$stmt->close();
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
