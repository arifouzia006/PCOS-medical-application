<?php
// Include config.php for database connection
include 'config.php';

$response = array();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $name = $_POST['name'];
    $meal_plan = $_POST['meal_plan'];
    $meal_percentage = $_POST['meal_percentage'];
    $exercise_plan = $_POST['exercise_plan'];
    $exercise_percentage = $_POST['exercise_percentage'];
    $meditation_routine = $_POST['meditation_routine'];
    $meditation_percentage = $_POST['meditation_percentage'];
    $no_meal = isset($_POST['no_meal']) ? $_POST['no_meal'] : null;
    $no_exercise = isset($_POST['no_exercise']) ? $_POST['no_exercise'] : null;
    $no_meditation = isset($_POST['no_meditation']) ? $_POST['no_meditation'] : null;

    // Validate data (simple example, you can add more validation if needed)
    if (empty($name) || !is_numeric($meal_percentage) || !is_numeric($exercise_percentage) || !is_numeric($meditation_percentage)) {
        $response = ["status" => "error", "message" => "Invalid input."];
    } else {
        try {
            // Insert data into the database
            $sql = "INSERT INTO health_plan (
                        name, meal_plan, meal_percentage, exercise_plan, exercise_percentage, 
                        meditation_routine, meditation_percentage, no_meal, no_exercise, no_meditation
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                    )";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssss", $name, $meal_plan, $meal_percentage, $exercise_plan, $exercise_percentage, $meditation_routine, $meditation_percentage, $no_meal, $no_exercise, $no_meditation);
            $stmt->execute();

            $response = ["status" => "success", "message" => "Data successfully inserted!"];
        } catch (\Exception $e) {
            $response = ["status" => "error", "message" => $e->getMessage()];
        }
    }
} else {
    $response = ["status" => "error", "message" => "No data submitted."];
}

// Set the Content-Type to application/json
header('Content-Type: application/json');
echo json_encode($response);
?>