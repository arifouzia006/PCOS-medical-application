<?php
header('Content-Type: application/json'); 

include("config.php");

$response = array(); 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Corrected SQL query to select only the role based on username and password
    $sql = "SELECT role FROM users WHERE username = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();

    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    // Change the condition to check if $row is not null (indicating a successful fetch)
    if ($row) {
        $response['success'] = true;
        $response['message'] = "Login Successful";
        $response['role'] = $row['role']; // Add role to response

        $personalDetailsSql = "SELECT COUNT(*) as personal_details_count FROM personal_details WHERE name = ?";
        $personalDetailsStmt = $conn->prepare($personalDetailsSql);
        $personalDetailsStmt->bind_param("s", $username);
        $personalDetailsStmt->execute();

        $personalDetailsResult = $personalDetailsStmt->get_result();
        $personalDetailsRow = $personalDetailsResult->fetch_assoc();

        $response['existing_user'] = ($personalDetailsRow['personal_details_count'] > 0);
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid username or password";
        $response['existing_user'] = false;
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method";
    $response['existing_user'] = false;
}

echo json_encode($response); 
?>