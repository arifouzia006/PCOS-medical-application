<?php
// Include the database connection configuration
include("config.php");

$response = [];

// Assuming `confirmpassword` is handled on the client-side and not sent to the server
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $newpassword = $_POST['newpassword'];

    // Validate and sanitize user input as needed

    // Check if the username and email exist in the "users" table
    $sqlCheckUser = "SELECT id FROM users WHERE username = ? AND email = ?";
    $stmtCheckUser = $conn->prepare($sqlCheckUser);
    $stmtCheckUser->bind_param("ss", $username, $email);
    $stmtCheckUser->execute();
    $result = $stmtCheckUser->get_result();
    $userExists = $result->fetch_assoc();

    if ($userExists) {
        // Update the password in the "users" table
        $sqlUpdatePassword = "UPDATE users SET password = ? WHERE username = ? AND email = ?";
        $stmtUpdatePassword = $conn->prepare($sqlUpdatePassword);
        $stmtUpdatePassword->bind_param("sss", $newpassword, $username, $email);

        if ($stmtUpdatePassword->execute()) {
            $response['status'] = 'success';
            $response['message'] = 'Password updated successfully.';
        } else {
            $response['status'] = 'error';
            $response['message'] = 'Unable to update the password.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Username and/or email do not exist.';
    }
}

// Output the JSON response
echo json_encode($response);