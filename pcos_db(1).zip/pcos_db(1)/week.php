<?php
// Include database configuration file
include("config.php");

$response = array();

try {
    // Check if the request method is POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Collect the 'name', 'from_date', and 'to_date' from POST request
        $name = isset($_POST['name']) ? $_POST['name'] : null;
        $from_date = isset($_POST['from_date']) ? $_POST['from_date'] : null;
        $to_date = isset($_POST['to_date']) ? $_POST['to_date'] : null;
        
        // Check if name and dates are provided
        if (empty($name) || empty($from_date) || empty($to_date)) {
            throw new Exception("Name, From Date, and To Date are required.");
        }
        
        // Prepare SQL query to select the requested fields from the today_progress table for the given name and date range
        $sql = "SELECT day, calories_taken, exercise_duration, todays_feedback, no_of_steps, date 
                FROM today_progress 
                WHERE name = ? AND date BETWEEN ? AND ?";
                
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, 'sss', $name, $from_date, $to_date);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        // Check if any record exists
        if (mysqli_num_rows($result) > 0) {
            // Fetch the data
            $data = array();

            // Process data to ensure integer types where needed
            while ($row = mysqli_fetch_assoc($result)) {
                $row['day'] = (int) $row['day'];
                $row['calories_taken'] = (int) $row['calories_taken'];  // Assuming calorie data can be converted to integer
                $row['exercise_duration'] = (int) $row['exercise_duration'];
                $row['no_of_steps'] = (int) $row['no_of_steps'];
                $row['todays_feedback'] = (string) $row['todays_feedback'];  // Preserving as string
                $data[] = $row;
            }
            
            // Set success response
            $response['success'] = true;
            $response['message'] = "Data retrieved successfully.";
            $response['data'] = $data;
        } else {
            throw new Exception("No data found for the provided name and date range.");
        }
    } else {
        throw new Exception("Invalid request method. Please use POST.");
    }
} catch (Exception $e) {
    // Catch any exception and set the error message in response
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

// Close connection
mysqli_close($conn);

// Set header to return JSON content
header('Content-Type: application/json');
// Return response in JSON format
echo json_encode($response);
?>