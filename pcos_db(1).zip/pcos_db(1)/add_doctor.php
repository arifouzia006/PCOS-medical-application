<?php
header('Content-Type: application/json');

// Include the database configuration file
include 'config.php';

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input
    $user = mysqli_real_escape_string($conn, $_POST['username']);
    $pass = mysqli_real_escape_string($conn, $_POST['password']);  // Directly using the password without hashing
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);

    // Set default role to 'doctor' if none provided
    if (empty($role)) {
        $role = 'doctor';
    }

    // SQL query to insert data
    $sql = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)";

    // Prepare and bind
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        $response = ['success' => false, 'message' => "Prepare failed: " . $conn->error];
        echo json_encode($response);
        exit;
    }

    $stmt->bind_param("ssss", $user, $pass, $email, $role);

    // Execute the statement
    if ($stmt->execute()) {
        $response = ['success' => true, 'message' => "New record created successfully"];
    } else {
        $response = ['success' => false, 'message' => "Error: " . $stmt->error];
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Output the JSON response
    echo json_encode($response);
}
?>
