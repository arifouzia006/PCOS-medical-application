<?php
// Include the config.php file for database connection
include 'config.php';

if (!empty($_POST['name']) && !empty($_POST['dates'])) {
    $name = $_POST['name'];
    $datesString = $_POST['dates']; // This is a string
    $datesArray = explode(',', $datesString); // Convert string to array

    try {
        $insertedDates = [];
        $insertStmt = $conn->prepare("INSERT INTO calender (name, calendar_date) VALUES (?, ?)");
        $insertStmt->bind_param('ss', $nameParam, $dateParam);

        foreach ($datesArray as $date) {
            $nameParam = $name;
            $dateParam = trim($date); // Trim the date string

            $insertStmt->execute();
            $insertedDates[] = $date;
        }

        $insertStmt->close();

        if (!empty($insertedDates)) {
            $response = ['message' => 'Data inserted successfully.', 'inserted_dates' => $insertedDates];
        } else {
            $response = ['message' => 'No new dates were inserted. All provided dates already exist.'];
        }
        echo json_encode($response);
    } catch (Exception $e) {
        $error_response = ['error' => 'Database error: ' . $e->getMessage()];
        echo json_encode($error_response);
    }
} else {
    $error_response = ['error' => 'Invalid input. Name and dates are required.'];
    echo json_encode($error_response);
}

// Close the connection
$conn->close();
?>
