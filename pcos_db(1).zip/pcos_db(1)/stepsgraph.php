<?php
// Include the database connection configuration
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the 'name' parameter is provided
    if (isset($_POST['name'])) {
        $name = $_POST['name'];

        // Prepare SQL statement to fetch the day and steps_count
        $sql = "SELECT day, steps_count FROM daily_steps WHERE name = ? ORDER BY day ASC";
        $stmt = $conn->prepare($sql);
        
        // Bind parameters
        $stmt->bind_param("s", $name);
        
        // Execute the query
        if($stmt->execute()) {
            $result = $stmt->get_result();
            // Check if any rows were returned
            if($result->num_rows > 0) {
                $days = [];
                $steps_counts = [];
                while ($row = $result->fetch_assoc()) {
                    // Convert day to string before adding to the days array
                    $days[] = (string)$row['day']; // or use strval($row['day']);
                    // Cast steps_count to double
                    $steps_counts[] = (double)$row['steps_count'];
                }

                $response['success'] = true;
                $response['message'] = "Data fetched successfully.";
                $response['days'] = $days; // Days array (as strings)
                $response['steps_counts'] = $steps_counts; // Steps count array as double
            } else {
                // No data found for the given name
                $response['success'] = false;
                $response['message'] = "No data found for the provided name.";
            }
        } else {
            // Query execution failed
            $response['success'] = false;
            $response['message'] = "Failed to execute query.";
        }
    } else {
        // Name not provided in the POST request
        $response['success'] = false;
        $response['message'] = "Name is required.";
    }
} else {
    // Invalid request method
    $response['success'] = false;
    $response['message'] = "Invalid request method. Please use POST.";
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>