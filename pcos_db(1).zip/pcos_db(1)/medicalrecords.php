<?php
header('Content-Type: application/json');

include("config.php"); 
error_reporting(E_ALL);
ini_set('display_errors', 1);

$uploadDir = "uploads/";

function uploadImages($fieldName, $uploadDir) {
    $result = [];

    if (isset($_FILES[$fieldName]) && is_array($_FILES[$fieldName]["name"])) {
        foreach ($_FILES[$fieldName]["name"] as $key => $value) {
            $targetFile = $uploadDir . basename($_FILES[$fieldName]["name"][$key]);
            if (move_uploaded_file($_FILES[$fieldName]["tmp_name"][$key], $targetFile)) {
                $result[] = $targetFile;
            } else {
                $result[] = null;
            }
        }
    } elseif (isset($_FILES[$fieldName])) {
        $targetFile = $uploadDir . basename($_FILES[$fieldName]["name"]);
        if (move_uploaded_file($_FILES[$fieldName]["tmp_name"], $targetFile)) {
            $result[] = $targetFile;
        } else {
            $result[] = null;
        }
    }

    return $result;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image']) && isset($_POST['name'])) {
    $name = $_POST['name'];
    $imagePaths = uploadImages('image', $uploadDir); 
    foreach($imagePaths as $uploadPath) {
        if($uploadPath) {
            $sql = "INSERT INTO medical_record (name, record_path) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $name, $uploadPath);

            if (!$stmt->execute()) {
                echo json_encode(["error" => "Error inserting image details into the database: " . $stmt->error]);
                return; 
            }
        } else {
            echo json_encode(["error" => "Error uploading one or more image files."]);
            return; 
        }
    }
    echo json_encode(["message" => "Image details inserted into the database successfully."]);

} else {
    echo json_encode(["error" => "Invalid request. Please make sure you are sending a POST request with all required fields and including an 'image' file."]);
}
?>