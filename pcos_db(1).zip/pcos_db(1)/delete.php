<?php
// Include the database configuration
include 'config.php'; // Adjust the path if necessary

if (isset($_GET['username'])) {
    $usernameToDelete = $_GET['username'];

    // Prepare deletion queries
    $deleteQueries = [
        'personaldetails' => 'DELETE FROM personal_details WHERE name = ?',
        'users' => 'DELETE FROM users WHERE username = ?',
        'signup' => 'DELETE FROM signup WHERE username = ?',
        'leaderboard' => 'DELETE FROM leaderboard WHERE Name = ?'
    ];

    $errors = [];
    $successMessages = [];

    // Execute each delete query
    foreach ($deleteQueries as $table => $query) {
        $stmt = $conn->prepare($query);
        if ($stmt === false) {
            $errors[] = "Error preparing statement for $table: " . $conn->error;
            continue;
        }

        $stmt->bind_param("s", $usernameToDelete);

        if ($stmt->execute()) {
            $successMessages[] = "Record deleted from $table successfully.";
        } else {
            $errors[] = "Error deleting record from $table: " . $stmt->error;
        }
        $stmt->close();
    }

    // Prepare the response
    if (empty($errors)) {
        $response = [
            'status' => 'success',
            'message' => implode(" ", $successMessages)
        ];
    } else {
        $response = [
            'status' => 'error',
            'message' => implode(" ", $errors)
        ];
    }

    echo json_encode($response);

} else {
    $response = [
        'status' => 'error',
        'message' => 'username parameter is missing'
    ];
    echo json_encode($response);
}

// Close the connection
$conn->close();
?>
