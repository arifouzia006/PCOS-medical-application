<?php
// Include the database configuration file
include 'config.php';

// Set content-type to JSON
header('Content-Type: application/json');

// Validate input data from $_POST
$name = isset($_POST['name']) ? $_POST['name'] : '';
$mild = isset($_POST['mild']) ? (float)$_POST['mild'] : 0.0;
$moderate = isset($_POST['moderate']) ? (float)$_POST['moderate'] : 0.0;
$severe = isset($_POST['severe']) ? (float)$_POST['severe'] : 0.0;

// Calculate the next assessment date (14 days from today)
$nextAssessmentDate = (new DateTime())->add(new DateInterval('P14D'))->format('Y-m-d');

// Check if the input data is valid
if (empty($name)) {
    echo json_encode(['error' => 'Name is required']);
    exit;
}

// Prepare SQL statement to check if the name already exists
if ($checkStmt = $conn->prepare("SELECT * FROM score WHERE name = ?")) {
    $checkStmt->bind_param("s", $name);
    $checkStmt->execute();
    $result = $checkStmt->get_result();

    if ($result->num_rows > 0) {
        // Name exists, update the record
        $updateSql = "UPDATE score SET mild = ?, moderate = ?, severe = ?, next_assessment_date = ? WHERE name = ?";
        if ($updateStmt = $conn->prepare($updateSql)) {
            $updateStmt->bind_param("dddss", $mild, $moderate, $severe, $nextAssessmentDate, $name);
            if ($updateStmt->execute()) {
                echo json_encode(['success' => 'Record updated successfully']);
            } else {
                echo json_encode(['error' => 'Error updating record: ' . $updateStmt->error]);
            }
            $updateStmt->close();
        } else {
            echo json_encode(['error' => 'Failed to prepare update statement: ' . $conn->error]);
        }
    } else {
        // Name does not exist, insert a new record
        $insertSql = "INSERT INTO score (name, mild, moderate, severe, next_assessment_date) VALUES (?, ?, ?, ?, ?)";
        if ($insertStmt = $conn->prepare($insertSql)) {
            $insertStmt->bind_param("sddds", $name, $mild, $moderate, $severe, $nextAssessmentDate);
            if ($insertStmt->execute()) {
                echo json_encode(['success' => 'New record created successfully']);
            } else {
                echo json_encode(['error' => 'Error inserting record: ' . $insertStmt->error]);
            }
            $insertStmt->close();
        } else {
            echo json_encode(['error' => 'Failed to prepare insert statement: ' . $conn->error]);
        }
    }
    $checkStmt->close();
} else {
    echo json_encode(['error' => 'Failed to prepare check statement: ' . $conn->error]);
}

$conn->close();
?>
