<?php
include 'config.php'; // Assuming this file contains the MySQLi connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    if (empty($name)) {
        http_response_code(400);
        echo json_encode(['error' => 'Name is required']);
        exit;
    }

    $query = "SELECT calendar_date FROM calender WHERE name = ?";

    try {
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param("s", $name);
            $stmt->execute();
            $result = $stmt->get_result();
            $dates = [];
            while ($row = $result->fetch_assoc()) {
                $dates[] = $row['calendar_date'];
            }

            if (!empty($dates)) {
                echo json_encode(['name' => $name, 'dates' => $dates]);
            } else {
                http_response_code(404);
                echo json_encode(['error' => 'No dates found for the provided name']);
            }

            $stmt->close();
        } else {
            throw new Exception("Failed to prepare statement.");
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method. Only POST is allowed']);
}

$conn->close();
?>
