<?php
include("config.php");

$response = array();

try {
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Collect form data
        $name = $_POST['name'];
        $calories_taken = $_POST['calories_taken'];
        $no_of_steps = $_POST['no_of_steps'];
        $exercise_duration = $_POST['exercise_duration'];
        $feedback = $_POST['todays_feedback'];
        $date = $_POST['date']; // Ensure this is in 'Y-m-d' format.

        // Calculate score
        $score = $calories_taken + $no_of_steps + $exercise_duration; // Adjust calculation as needed.

        // Check if the date already exists for the given name
        $sqlDateExists = "SELECT * FROM today_progress WHERE name = ? AND date = ?";
        $stmtDateExists = $conn->prepare($sqlDateExists);
        $stmtDateExists->bind_param("ss", $name, $date);
        $stmtDateExists->execute();
        $resultDateExists = $stmtDateExists->get_result();

        if ($resultDateExists->num_rows > 0) {
            $response['success'] = false;
            $response['message'] = "Entry for the given date and name already exists.";
        } else {
            // Fetch the most recent day value for the given name
            $sqlFetchDay = "SELECT day FROM today_progress WHERE name = ? ORDER BY day DESC LIMIT 1";
            $stmtFetchDay = $conn->prepare($sqlFetchDay);
            $stmtFetchDay->bind_param("s", $name);
            $stmtFetchDay->execute();
            $resultFetchDay = $stmtFetchDay->get_result();

            $day = 1; // Default to 1 if no previous records are found
            if ($resultFetchDay->num_rows > 0) {
                $row = $resultFetchDay->fetch_assoc();
                $day = $row['day'] + 1; // Increment day by 1
            }

            // Insert the new progress record along with the calculated score and incremented day
            $sqlInsert = "INSERT INTO today_progress (name, date, calories_taken, no_of_steps, exercise_duration, todays_feedback, score, day) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmtInsert = $conn->prepare($sqlInsert);
            $stmtInsert->bind_param("ssssssss", $name, $date, $calories_taken, $no_of_steps, $exercise_duration, $feedback, $score, $day);
            
            if ($stmtInsert->execute()) {
                // After successfully inserting into today_progress, insert into daily_steps
                $sqlDailySteps = "INSERT INTO daily_steps (name, day, steps_count) VALUES (?, ?, ?)";
                $stmtDailySteps = $conn->prepare($sqlDailySteps);
                $stmtDailySteps->bind_param("sss", $name, $day, $no_of_steps);

                if (!$stmtDailySteps->execute()) {
                    throw new Exception("Failed to add steps record.");
                }

                $sqlLeaderboardUpdate = "INSERT INTO leaderboard (Name, Totalscore) VALUES (?, ?) ON DUPLICATE KEY UPDATE Totalscore = Totalscore + VALUES(Totalscore)";
                $stmtLeaderboard = $conn->prepare($sqlLeaderboardUpdate);
                $stmtLeaderboard->bind_param("ss", $name, $score);

                if ($stmtLeaderboard->execute()) {
                    $response['success'] = true;
                    $response['message'] = "Progress added, steps recorded, and leaderboard updated successfully.";
                } else {
                    throw new Exception("Failed to update leaderboard.");
                }
            } else {
                throw new Exception("Failed to add new progress record.");
            }
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Invalid request method.";
    }
} catch (Exception $e) {
    $response['success'] = false;
    $response['message'] = $e->getMessage();
}

$conn->close();
header('Content-Type: application/json');
echo json_encode($response);
?>