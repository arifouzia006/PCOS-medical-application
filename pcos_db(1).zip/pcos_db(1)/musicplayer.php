<?php
header('Content-Type: application/json');

// Include the config.php file
include 'config.php';

$uploadDir = "uploads/";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['audio']) && isset($_POST['audio_name']) && isset($_POST['category']) && isset($_POST['audio_description']) && isset($_POST['duration'])) {
    // Retrieve POST data
    $audioName = $_POST['audio_name'];
    $category = $_POST['category'];
    $audioDescription = $_POST['audio_description'];
    $duration = $_POST['duration']; // Retrieve duration from POST data

    // Retrieve file data
    $file = $_FILES['audio'];
    $fileName = basename($file['name']);
    $uploadPath = $uploadDir . $fileName;

    // Attempt to move the uploaded file
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        // File uploaded successfully, insert details into database
        $stmt = $conn->prepare("INSERT INTO meditation (audio_name, category, audio_path, audio_description, duration) VALUES (?, ?, ?, ?, ?)");

        // For MySQLi, bind parameters
        $stmt->bind_param("sssss", $audioName, $category, $uploadPath, $audioDescription, $duration);

        // Execute the statement
        if ($stmt->execute()) {
            echo json_encode(["message" => "Audio details inserted into the database successfully."]);
        } else {
            // Error handling
            echo json_encode(["error" => "Error inserting audio details into the database: " . $conn->error]);
        }
    } else {
        echo json_encode(["error" => "Error uploading the audio file."]);
    }
} else {
    echo json_encode(["error" => "Invalid request. Please make sure you are sending a POST request with all required fields and including an 'audio' file and the 'duration'."]);
}

// Close the database connection
$conn->close();
?>