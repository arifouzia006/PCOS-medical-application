<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = isset($_POST['name']) ? trim($_POST['name']) : '';
    if (empty($name)) {
        http_response_code(400);
        echo json_encode(['error' => 'Name is required']);
        exit;
    }

    $query = "SELECT calendar_date FROM calender WHERE name = ?";

    try {
        $stmt = $conn->prepare($query);
        $stmt->bind_param('s', $name);
        $stmt->execute();
        $result = $stmt->get_result();
        $dates = $result->fetch_all(MYSQLI_ASSOC);

        if ($dates) {
            // Extract only the calendar_date column values
            $dates = array_column($dates, 'calendar_date');
            echo json_encode(['name' => $name, 'dates' => $dates]);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'No dates found for the provided name']);
        }
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Invalid request method. Only POST is allowed']);
}
?>
