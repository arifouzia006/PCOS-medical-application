<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "pcos";

$conn = new mysqli($servername, $username, $password, $dbname);

$response = array(); // Initialize a response array

if ($conn->connect_error) {
    $response["error"] = "Connection failed: " . $conn->connect_error;
} elseif ($_POST) {
    $weightgoalsId = $_POST['weightgoals_id'];
    $mealType = $_POST['meal_type'];
    $foodName = $_POST['food_name'];
    $description = $_POST['description'];

    // Handle image upload
    $targetDir = "uploads/"; // Specify the directory where you want to save the uploaded images
    $targetFile = $targetDir . basename($_FILES["image"]["name"]);

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
        // The image has been successfully uploaded, and $targetFile contains the path to the saved image.

        // Insert doctor-uploaded recommendations into the doctor_recommendations table
        $sql = "INSERT INTO doctor_recommendations (weightgoals_id, meal_type, food_name, image_url, description)
        VALUES ('$weightgoalsId', '$mealType', '$foodName', '$targetFile', '$description')";

        if ($conn->query($sql) === TRUE) {
            $response["success"] = "Recommendations submitted successfully.";
        } else {
            $response["error"] = "Error submitting recommendations: " . $conn->error;
        }
    } else {
        $response["error"] = "Error uploading the image.";
    }
}

// Close the database connection
$conn->close();

// Send the JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
