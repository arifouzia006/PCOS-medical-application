<?php
// Include the database connection from config.php
include 'config.php';

header('Content-Type: application/json'); // Set response type to JSON

// Check if the form was submitted using POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect username and password from POST data
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM admin WHERE Name = ? AND password = ?");
    $stmt->bind_param('ss', $username, $password);

    // Execute the statement
    $stmt->execute();

    // Get the result
    $result = $stmt->get_result();

    // Check if any record was found
    if ($result->num_rows > 0) {
        // Username and password match
        echo json_encode(['success' => true, 'message' => 'Login successful']);
    } else {
        // No matching record found
        echo json_encode(['success' => false, 'message' => 'Invalid username or password']);
    }

    // Close statement
    $stmt->close();
} else {
    // Not POST request
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

// Close connection
$conn->close();
?>
