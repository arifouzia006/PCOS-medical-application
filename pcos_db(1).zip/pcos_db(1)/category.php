<?php
// Include the config.php for the database connection
include 'config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch data from the request
    $username = $_POST['name'] ?? '';

    if (!empty($username)) {
        $stmt = $conn->prepare("SELECT mild, moderate, severe FROM score WHERE name = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_assoc();

        if ($data) {
            // Cast the scores to double to ensure correct data type in JSON
            $data = [
                'mild' => (double)$data['mild'],
                'moderate' => (double)$data['moderate'],
                'severe' => (double)$data['severe']
            ];

            // Success response
            echo json_encode([
                'success' => true,
                'message' => 'Data fetched successfully',
                'data' => $data
            ]);
        } else {
            // No records found
            echo json_encode([
                'success' => false,
                'message' => 'No records found for the provided username.'
            ]);
        }
        $stmt->close();
    } else {
        // Username not provided
        echo json_encode([
            'success' => false,
            'message' => 'Username is required.'
        ]);
    }
} else {
    // Invalid request method
    echo json_encode([
        'success' => false,
        'message' => 'Invalid request method. Please use POST.'
    ]);
}

// Close the database connection
$conn->close();
?>
