<?php
header('Content-Type: application/json'); // Set the response content type to JSON

// Include the database connection configuration
include("config.php");

$response = array(); // Create an associative array for the response

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate and sanitize user input as needed

    // Check if the username or email already exists in the signup table
    $checkSql = "SELECT COUNT(*) as count FROM signup WHERE username = ? OR email = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("ss", $username, $email);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $result = $result->fetch_assoc();

    if ($result['count'] == 0) {
        // Check if the username or email already exists in the users table
        $checkUsersSql = "SELECT COUNT(*) as count FROM users WHERE username = ? OR email = ?";
        $checkUsersStmt = $conn->prepare($checkUsersSql);
        $checkUsersStmt->bind_param("ss", $username, $email);
        $checkUsersStmt->execute();
        $resultUsers = $checkUsersStmt->get_result();
        $resultUsers = $resultUsers->fetch_assoc();

        if ($resultUsers['count'] == 0) {
            // Passwords match, proceed with insertion
            $signupSql = "INSERT INTO signup (username, email, password, confirm_password) VALUES (?, ?, ?, ?)";
            $signupStmt = $conn->prepare($signupSql);
            $signupStmt->bind_param("ssss", $username, $email, $password, $confirm_password);

            // Insert into signup table
            if ($signupStmt->execute()) {
                // Insert into users table
                $usersSql = "INSERT INTO users (username, password, email) VALUES (?, ?, ?)";
                $usersStmt = $conn->prepare($usersSql);
                $usersStmt->bind_param("sss", $username, $password, $email);

                if ($usersStmt->execute()) {
                    $response['success'] = true;
                    $response['message'] = "Signup Successful";
                } else {
                    $response['success'] = false;
                    $response['message'] = "Error: Unable to insert data into the users table.";
                }
            } else {
                $response['success'] = false;
                $response['message'] = "Error: Unable to insert data into the signup table.";
            }
        } else {
            $response['success'] = false;
            $response['message'] = "Error: Username or email already exists.";
        }
    } else {
        $response['success'] = false;
        $response['message'] = "Patient already exists.";
    }
}

// Close the database connection
$conn->close();

echo json_encode($response); // Encode the response as JSON and echo it
?>