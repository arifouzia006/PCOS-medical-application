<?php
// Include the database connection configuration
include("config.php");

$response = array();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $day = $_POST['day'];
    $calories_taken = $_POST['calories_taken'];
    $exercise_duration = $_POST['exercise_duration'];
    $todays_feedback = $_POST['todays_feedback'];

    // Validate and sanitize user input as needed

    // Calculate the score
    $score = calculateScore($exercise_duration, $calories_taken);

    // Insert data into the "today_progress" table, including the "score" column
    $sql = "INSERT INTO today_progress (day, calories_taken, exercise_duration, todays_feedback, score) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $day, $calories_taken, $exercise_duration, $todays_feedback, $score);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Progress inserted successfully.";
    } else {
        $response['success'] = false;
        $response['message'] = "Error: Unable to insert data into the 'today_progress' table. " . $conn->error;
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

// Return the JSON response
header('Content-Type: application/json');
echo json_encode($response);

// Function to calculate the score
function calculateScore($exercise_duration, $calories_taken) {
    // Define your scoring logic here based on exercise duration and calories taken
    // For example, you can give a higher score for longer exercise duration and lower score for higher calories taken
    $score = ($exercise_duration * 20) + ($calories_taken * 10);

    // Make sure the score is never negative
    if ($score < 0) {
        $score = 0;
    }

    return $score;
}
?>