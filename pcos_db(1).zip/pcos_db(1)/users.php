<?php
header('Content-Type: application/json'); // Set the response content type to JSON

// Include the database connection configuration
include("config.php");

$response = array(); // Create an associative array for the response

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $role = $_POST['role'];

    try {
        // Check if the username already exists
        $checkUsernameQuery = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($checkUsernameQuery);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Username already exists
            $response['success'] = false;
            $response['message'] = "Username already exists. Please choose a different username.";
        } else {
            // Insert data into the database
            $insertQuery = "INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("ssss", $username, $password, $email, $role);

            if ($insertStmt->execute()) {
                $response['success'] = true;
                $response['message'] = "User registration successful!";
            } else {
                $response['success'] = false;
                $response['message'] = "Error: Unable to insert data into the database.";
            }
        }
    } catch (Exception $e) {
        $response['success'] = false;
        $response['message'] = "Error: " . $e->getMessage();
    }
} else {
    $response['success'] = false;
    $response['message'] = "Invalid request method.";
}

// Close the database connection
$conn->close();

echo json_encode($response); // Encode the response as JSON and echo it
?>